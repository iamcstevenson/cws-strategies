CWS STRATEGIES — WORDPRESS SETUP
=================================

What's in this folder
  cws-strategies-theme.zip   The block theme (colors, fonts, header, footer, page layout).
  cws-pages.xml              Import file that creates the five pages with all their content.

1. Install the theme
   Appearance > Themes > Add New Theme > Upload Theme > choose cws-strategies-theme.zip > Install > Activate.
   (WordPress.com: theme uploads require the Business plan or higher.)

2. Set permalinks
   Settings > Permalinks > "Post name" > Save. The menu links use /digital-services/, /about/, etc.

3. Import the pages
   Tools > Import > WordPress > Install Now (if prompted) > Run Importer > choose cws-pages.xml.
   Assign the content to your user. Skip "Download and import file attachments" (there are none).
   This creates: Home, Digital Services, Political Consulting, Open House Hospitality Group, About, Contact.

4. Make "Home" the front page
   Settings > Reading > "Your homepage displays: A static page" > Homepage: Home > Save.

5. Fill in the placeholders
   - Digital Services: [PRICE], [PRICE] / mo, [RATE] / hr
   - About: replace the two gray boxes with Image blocks (Cherlynn's and Christian's photos),
     and fill in Christian's [TITLE]
   - Open House Hospitality Group: all [Placeholder] text, both photos, and the brokerage disclosure line
   - Contact: [EMAIL ADDRESS], and add a form block
       WordPress.com: insert the "Form" block.
       Other hosts: install WPForms Lite (or Jetpack) and insert its form block.
       Suggested fields: Name, Email, Organization, I'm reaching out about
       (Website / AI / Salesforce / Political campaign / Other), Message.

6. Site icon
   Appearance > Editor > (Site Identity / Settings) > Site Icon: upload favicon/icon-512.png from the logo kit.

Editing later
   Page text: edit each page normally in the block editor.
   Header and footer: Appearance > Editor > Patterns > Template Parts.
   Colors and fonts: Appearance > Editor > Styles (palette is locked to the four brand colors + a light gray background).

Fonts are bundled in the theme (no Google Fonts calls), which is faster and avoids privacy issues.
